package com.railways.ecsoket.services;


public interface ApiService {
}
