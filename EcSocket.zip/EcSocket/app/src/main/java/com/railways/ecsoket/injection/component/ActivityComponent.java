package com.railways.ecsoket.injection.component;

import com.railways.ecsoket.ui.activity.HomeActivity;
import com.railways.ecsoket.injection.PerActivity;
import com.railways.ecsoket.injection.module.ActivityModule;

import dagger.Subcomponent;

@PerActivity
@Subcomponent(modules = ActivityModule.class)
public interface ActivityComponent {

    void inject(HomeActivity homeActivity);


}
