package com.railways.ecsoket.constants;

/**
 * Created by nakul on 30/03/18.
 */

public class EcSocketConstants {

    public static final String USER_PREF_FILE = "UserDataPref";
    public static String Url="https://crisant.com/snt/";
}
