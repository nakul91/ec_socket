package com.railways.ecsoket.ui.activity;

import com.railways.ecsoket.base.BasePresenter;
import com.railways.ecsoket.data.PreferenceManager;
import com.railways.ecsoket.injection.ConfigPersistent;
import com.railways.ecsoket.services.ApiService;

import javax.inject.Inject;

/**
 * Created by nakul on 30/03/18.
 */

@ConfigPersistent
public class HomeActivityPresenter extends BasePresenter<HomeActivityView> {

    @Inject PreferenceManager mPref;

    private final ApiService apiService;

    @Inject
    HomeActivityPresenter(ApiService apiService) {
        this.apiService = apiService;
    }


}
