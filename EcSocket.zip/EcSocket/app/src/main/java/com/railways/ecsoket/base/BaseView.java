package com.railways.ecsoket.base;

public interface BaseView {

}
