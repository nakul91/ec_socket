package com.railways.ecsoket.ui.activity;


import com.railways.ecsoket.base.BaseView;

interface  HomeActivityView extends BaseView {
}
