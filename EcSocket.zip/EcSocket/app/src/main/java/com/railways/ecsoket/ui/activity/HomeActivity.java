package com.railways.ecsoket.ui.activity;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.railways.R;
import com.railways.ecsoket.base.BaseActivity;
import com.railways.ecsoket.data.PreferenceManager;
import com.railways.ecsoket.injection.component.ActivityComponent;

import javax.inject.Inject;

public class HomeActivity  extends BaseActivity implements HomeActivityView {
    @Inject
    PreferenceManager mPref;
    @Inject
    HomeActivityPresenter presenter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    protected int getLayout() {
        return R.layout.activity_home;
    }

    @Override
    protected void inject(ActivityComponent activityComponent) {
        activityComponent.inject(this);
    }

    @Override
    protected void attachView() {
        presenter.attachView(this);
    }

    @Override
    protected void detachPresenter() {
        presenter.detachView();
    }
}
